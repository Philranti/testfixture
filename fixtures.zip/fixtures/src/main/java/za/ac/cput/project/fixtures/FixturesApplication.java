package za.ac.cput.project.fixtures;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FixturesApplication {

	public static void main(String[] args) {
		SpringApplication.run(FixturesApplication.class, args);
	}

}
